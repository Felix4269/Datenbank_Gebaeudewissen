---
tags: [Energie, Heizwärmebedarf, Wärmegewinne, Gebäudetechnik]
skript: "Energieflüsse im Gebäude"
autor: "Prof. Markus Hubbuch"
version: "2026"
kapitel: "6.2"
titel: "Einfluss auf den Primärenergiebedarf"
---

> ◀ [[06_1_berechnung_energiebedarf|← Berechnung Energiebedarf]] · [[_Skript_Energie_MOC|↑ MOC]] · [[06_3_deckung_energiebedarf|Deckung Energiebedarf →]] ▶

---

# Energieflüsse im Gebäude – Kap. 6.2: Einfluss auf den Primärenergiebedarf

### 6.2 Einfluss auf den Primärenergiebedarf
Die dem Gebäude zugeführte Energie in Form von nutzbaren Energieträgern wie Heizöl, Erdgas,
Holzpellets oder elektrischem Strom wird als Endenergie bezeichnet. Diese Energieträger
müssen mit mehr oder weniger Verlusten aus der von der Natur gegebenen Primärenergie
aufbereitet werden. Sie müssen zudem zum Konsumenten hin transportiert werden, was ebenfalls
mit Verlusten behaftet ist.

Aus dem notwendigen Endenergiebedarf E und E des Gebäudes kann dann mit
Umrechnungsfaktoren berechnet werden, wie viel Primärenergie notwendig ist, die geforderte
Menge der Endenergie bereitzustellen (Abbildung 18 Bild von M. Hubbuch ). Diese
Umrechnungsfaktoren berücksichtigen, wie viel Primärenergie für Gewinnung, Aufbereitung resp.
Umwandlung und Transport im Mittel für eine Einheit Endenergie notwendig ist.
![[tab7_primarenergiefaktoren_ausgewahlter_endener.png]]


---

> ◀ [[06_1_berechnung_energiebedarf|← Berechnung Energiebedarf]] · [[_Skript_Energie_MOC|↑ MOC]] · [[06_3_deckung_energiebedarf|Deckung Energiebedarf →]] ▶

---
