---
tags: [Lueftung, Lueftungstechnik, Raumlufttechnik, Klimaanlage]
skript: "Lueftung"
autor: "Prof. Markus Hubbuch"
version: "2025"
kapitel: "1"
titel: "Aufgaben und Einteilung der Lüftungstechnik"
---

> [[_Skript_Lueftung_MOC|↑ MOC]] · [[02_bedarfsermittlung_luftraten|Bedarfsermittlung und Luftraten →]] ▶

---

# Lüftungstechnik – Kapitel 1: Aufgaben und Einteilung

## 1 Aufgaben und Einteilung der Lüftungstechnik

### 1.1 Aufgaben

#### Raumlufttechnik

Die Aufgaben der Raumlufttechnik können in zwei wesentliche Funktionen getrennt werden:

- Gewährleistung der Luftqualität (Schadstoffe, Gerüche, Feuchte)
- Gewährleistung der Lufttemperatur

Wenn mit der Lüftungsanlage primär geheizt wird, spricht man von einer Luftheizung. Eine Luftheizung ist der Heizungstechnik zugeordnet. Luftheizungen sind in der Schweiz eher selten.

Mit Lüftungstechnik wird ein Raum also belüftet und gekühlt, allenfalls auch teilweise beheizt. Wird gekühlt, erwärmt und die Feuchte beeinflusst, spricht man von einer Klimaanlage.

In der Vergangenheit wurden die beiden Funktionen Luftqualität und Kühlung oft kombiniert und gemeinsam der Lüftungstechnik aufgebürdet (→ Klimaanlagen). Um energieoptimierte, komfortable und wirtschaftliche Systeme zu ermöglichen, müssen diese beiden Aufgaben jedoch getrennt betrachtet werden.

Die Luftqualität kann (fast) nur mit Lüftungsmassnahmen beeinflusst werden. Eine gute Luftqualität zu gewährleisten ist deshalb die eigentliche Domäne der Lüftungstechnik.

Die Raumlufttemperatur dagegen kann auch mit anderen Massnahmen beeinflusst werden. Im Vordergrund stehen wasserführende Systeme wie die Radiatoren- oder Flächenheizung zur Raumerwärmung (→ Raumheizung). Für die Raumkühlung können Kühldecken oder thermoaktive Decken eingesetzt werden. Diese Systeme sind oft vorteilhaft gegenüber einer Lösung mit Lüftungsanlagen wie z. B. herkömmlichen Klimaanlagen. Kühldecken oder thermoaktive Decken können darüber hinaus auch zur Beheizung genutzt werden.

Für optimierte Anlagen müssen die Funktionen Heizen, Kühlen und Lüften integral geplant werden. Die Aufteilung dieser Gewerke auf einzelne Fachplaner führt nicht zu optimalen Lösungen.

#### Prozesslufttechnik

Spezialanlagen mit Lüftungstechnik können weitere Aufgaben haben, beispielsweise Transportaufgaben (pneumatische Förderanlagen, Rohrpost etc.), Trockner, Druckhaltung. Auf solche Prozesslufttechnik wird hier nicht weiter eingegangen. Vielmehr wollen wir uns auf die Raumlufttechnik konzentrieren.

### 1.2 Einteilung der Raumlufttechnik

Die Raumlüftung kann grundsätzlich auf zwei Arten erfolgen:

- **Freie Lüftung** (Lüftung ohne Ventilatorantrieb)
- **Mechanische Lüftung** (Lüftung mit Ventilatorantrieb)

Im Fall mechanische Lüftung ist oft auch freie Lüftung (über Fenster) zusätzlich möglich.

Die mechanische Lüftung wird gemäss Tabelle 1 in Anlagetypen unterteilt.

*Tabelle 1: Typen von raumlufttechnischen Anlagen nach Funktionen<sup>1</sup>*

![[tab1_typen_rlt_anlagen.png]]

#### Erläuterung

Gemäss SIA 410/1 ist in Koordinationsplänen die Farbe Blau zu verwenden zur allgemeinen Kennzeichnung von Installationen von RLT-Anlagen.

Zu RLT-Anlagen mit Zuluftüberschuss (insbesondere Zuluftanlagen) oder Abluftüberschuss (insb. Abluftanlagen) gehört zwingend ein Konzept, wie und woher die Luftdifferenz zu- oder abströmen kann.

Bei reinen Abluftanlagen mit Abwärmenutzung (AWN) wird die zurückgewonnene Wärme einem anderen System zugeführt.

Bei RLT-Anlagen kann die Kontrolle der Funktionen gemäss Tabelle 1.4 durch die Lüftungs- und Klimaanlage allein (Nur-Luft-System) oder in Kombination mit anderen Systemen wie Kühldecken oder Heizkörpern (kombiniertes System) erfolgen.

Lüftungsanlagen mit Lufterwärmung und Lüftungsanlagen mit Lufterwärmung und -befeuchtung können auch als Luftheizungen bezeichnet werden (mit und ohne Luftbefeuchtung), wenn sie als alleinige Heizung eines Raums dienen, d. h. als Nur-Luft-Systeme ausgeführt werden.

Bei der Kontrolle der Raumluftqualität durch die Steuerung und Regelung der Anlage werden die Möglichkeiten nach Tabelle 2 unterschieden.

*Tabelle 2: Arten der Steuerung/Regelung des Volumenstroms im Hinblick auf die Raumluftqualität gemäss SIA EN 16798-3<sup>2</sup>*

![[tab2_steuerung_regelung_volumenstrom.png]]

Zusätzlich kommen die beiden folgenden Typen von Raumluftanlagen vor:

- **Reinraumanlagen** (werden in diesem Skript nicht näher betrachtet)
- **Umluftanlagen** (heute nur in Ausnahmefällen zu empfehlen)

<sup>1</sup> Tabelle 1 in SIA 382/1, 2025

<sup>2</sup> Tabelle 2 in SIA 382/1, 2025

---

> [[_Skript_Lueftung_MOC|↑ MOC]] · [[02_bedarfsermittlung_luftraten|Bedarfsermittlung und Luftraten →]] ▶

---
