---
tags: [Lueftung, Lueftungstechnik, Raumlufttechnik, Klimaanlage, MOC]
skript: "Lueftung"
autor: "Prof. Markus Hubbuch"
---

# Lüftungstechnik – MOC

**Autor:** Prof. Markus Hubbuch
**Version:** 2025

---

## Kapitelübersicht

| Datei | Inhalt |
|---|---|
| [[01_aufgaben_einteilung\|Kap. 1: Aufgaben und Einteilung]] | Aufgaben der RLT, Einteilung der Raumlufttechnik |
| [[02_1_schadstoffabfuhr_luftfuehrung\|Kap. 2.1: Schadstoffabfuhr und Luftführung]] | Schadstoffabfuhr, Luftvolumenstrom, Luftführungssysteme |
| [[02_2_thermischer_raumkomfort\|Kap. 2.2: Thermischer Raumkomfort]] | Temperaturen, Strahlungsasymmetrie, operative Temperatur |
| [[03_1_freie_lueftung\|Kap. 3.1: Freie Lüftung]] | Fugen-, Fenster-, Schacht-, Dachaufsatzlüftung |
| [[03_2_mechanische_lueftung\|Kap. 3.2: Mechanische Lüftung]] | Abluft-, Zuluft-, Lüftungs- und Klimaanlagen |
| [[04_1_nur_luft_anlagen\|Kap. 4.1: Nur-Luft-Anlagen]] | Einkanal-, Mehrzonen-, VAV-Anlagen |
| [[04_2_kombinierte_anlagen\|Kap. 4.2: Kombinierte Anlagen]] | Klimakonvektoren, Kühlbalken, Thermoaktive Decken |
| [[05_1_filter\|Kap. 5.1: Filter]] | Staubfilter, Filterklassen, Aktivkohle, Elektrofilter |
| [[05_2_ventilatoren\|Kap. 5.2: Ventilatoren]] | Radial-, Axialventilatoren, Antrieb, Frequenzumformer |
| [[05_3_waermerueckgewinnung\|Kap. 5.3: Wärmerückgewinnung]] | WRG-Rad, Enthalpietauscher, Plattentauscher, Verbund-WRG |
| [[05_4_lufterhitzer_kuehler\|Kap. 5.4: Lufterhitzer und -kühler]] | Luftregister, Frostschutz, Gegenstromprinzip |
| [[05_5_luftbefeuchter\|Kap. 5.5: Luftbefeuchter]] | Wasserverdunstung, Dampfbefeuchter, Hygiene |
| [[05_6_kanalnetz\|Kap. 5.6: Kanalnetz]] | Luftleitungen, Dichtigkeit, Volumenstromregler |
| [[06_Schallanforderungen\|Kap. 6: Schallanforderungen]] | Raumschall, Schallübertragung, Körperschall |

---

*Zurück zum Hauptindex: [[00_Wissensbank_Index]]*
