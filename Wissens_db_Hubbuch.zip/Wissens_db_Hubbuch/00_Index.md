---
tags: [Hubbuch, Wissensdatenbank, MOC, Index]
---

# Wissensdatenbank – Prof. Markus Hubbuch

Vorlesungsskripte für Energie- und Gebäudemanagement / Gebäudetechnik  
ZHAW, Institut für Facility Management

---

## Skripte

| Skript | Autor | Version |
|---|---|---|
| [[_Skript_Energie_MOC|Energieflüsse im Gebäude]] | Prof. Markus Hubbuch | 2026 |
| [[_Skript_Lueftung_MOC|Lüftungstechnik]] | Prof. Markus Hubbuch | 2022 |
| [[_Skript_Bauphysik_MOC|Bauphysik]] | Prof. Markus Hubbuch | 2026 |

---

## Kapitelübersicht

### [[_Skript_Energie_MOC|Energieflüsse im Gebäude]]

| Kapitel | Inhalt |
|---|---|
| [[00_Titelseite_TOC|Kap. 0]] | Titelseite und Inhaltsverzeichnis |
| [[01_Grundlagen|Kap. 1]] | Grundlagen |
| [[02_Waermeverluste|Kap. 2]] | Wärmeverluste |
| [[03_Waermegewinne|Kap. 3]] | Wärmegewinne |
| [[04_Heizwaermebedarf|Kap. 4]] | Heizwärmebedarf |
| [[05_Warmwasser|Kap. 5]] | Wärmebedarf Warmwasser |
| [[06_Energiebedarf|Kap. 6]] | Energiebedarf des Gebäudes |
| [[07_Sommerlicher_Waermeschutz|Kap. 7]] | Sommerlicher Wärmeschutz |
| [[08_Anhang|Kap. 8]] | Anhang |

### [[_Skript_Lueftung_MOC|Lüftungstechnik]]

| Kapitel | Inhalt |
|---|---|
| [[00_Titelseite_TOC|Kap. 0]] | Titelseite und Inhaltsverzeichnis |
| [[01_Aufgaben_Einteilung|Kap. 1]] | Aufgaben und Einteilung der Lüftungstechnik |
| [[02_Bedarfsermittlung|Kap. 2]] | Bedarfsermittlung, Luftraten |
| [[03_Lueftungssysteme|Kap. 3]] | Lüftungssysteme |
| [[04_Bauarten|Kap. 4]] | Bauarten von Lüftungs- und Klimaanlagen |
| [[05_Komponenten|Kap. 5]] | Komponenten der Lüftungs- und Klimatechnik |
| [[06_Schallanforderungen|Kap. 6]] | Schallanforderungen |

### [[_Skript_Bauphysik_MOC|Bauphysik]]

| Kapitel | Inhalt |
|---|---|
| [[00_Titelseite_TOC|Kap. 0]] | Titelseite und Inhaltsverzeichnis |
| [[01_Grundlagen|Kap. 1]] | Grundlagen Bauphysik |
| [[02_Waermeverluste_Trans|Kap. 2]] | Verringerung der Wärmeverluste durch Transmission |
| [[03_Theorie_Waermedurchgang|Kap. 3]] | Theorie Wärmedurchgang |
| [[04_Theorie_Feuchte|Kap. 4]] | Theorie der feuchten Luft |
| [[05_Luftdichtheit|Kap. 5]] | Luftdichtheit eines Gebäudes |

---

*Alle Inhalte © Prof. Markus Hubbuch, ZHAW*
