---
tags: [Hubbuch, Wissensdatenbank, Index]
---

# Wissensdatenbank – Prof. Markus Hubbuch

Vorlesungsskripte für Energie- und Gebäudemanagement / Gebäudetechnik  
ZHAW, Institut für Facility Management

---

## Skripte

| Skript | Autor | Version | MOC |
|---|---|---|---|
| Lüftungstechnik | Prof. Markus Hubbuch | 2022 | [[_Skript_Lueftung_MOC\|→ MOC Lüftung]] |
| Bauphysik | Prof. Markus Hubbuch | 2026 | [[_Skript_Bauphysik_MOC\|→ MOC Bauphysik]] |
| Energieflüsse im Gebäude | Prof. Markus Hubbuch | 2026 | [[_Skript_Energie_MOC\|→ MOC Energie]] |

---

## Lüftungstechnik

| Kapitel | Inhalt |
|---|---|
| [[01_aufgaben_einteilung\|Kap. 1]] | Aufgaben und Einteilung der Raumlufttechnik |
| [[02_1_schadstoffabfuhr_luftfuehrung\|Kap. 2.1]] | Schadstoffabfuhr und Luftführungssysteme |
| [[02_2_thermischer_raumkomfort\|Kap. 2.2]] | Thermischer Raumkomfort |
| [[03_1_freie_lueftung\|Kap. 3.1]] | Freie Lüftung |
| [[03_2_mechanische_lueftung\|Kap. 3.2]] | Mechanische Lüftung |
| [[04_1_nur_luft_anlagen\|Kap. 4.1]] | Nur-Luft-Anlagen |
| [[04_2_kombinierte_anlagen\|Kap. 4.2]] | Kombinierte Lüftungs- und Klimaanlagen |
| [[05_1_filter\|Kap. 5.1]] | Filter |
| [[05_2_ventilatoren\|Kap. 5.2]] | Ventilatoren |
| [[05_3_waermerueckgewinnung\|Kap. 5.3]] | Wärmerückgewinnung |
| [[05_4_lufterhitzer_kuehler\|Kap. 5.4]] | Lufterhitzer und -kühler |
| [[05_5_luftbefeuchter\|Kap. 5.5]] | Luftbefeuchter |
| [[05_6_kanalnetz\|Kap. 5.6]] | Kanalnetz (Luftleitungen) |
| [[06_Schallanforderungen\|Kap. 6]] | Schallanforderungen |

---

## Bauphysik

| Kapitel | Inhalt |
|---|---|
| [[01_Grundlagen\|Kap. 1]] | Grundlagen Bauphysik |
| [[02_Waermeverluste_Trans\|Kap. 2]] | Verringerung der Wärmeverluste durch Transmission |
| [[03_1_2_waermedurchgang_waermeleitung\|Kap. 3.1–3.2]] | Wärmedurchgang und Wärmeleitung |
| [[03_3_4_waermeuebergang_konvektion\|Kap. 3.3–3.4]] | Wärmeübergang und Konvektion |
| [[03_5_strahlung\|Kap. 3.5]] | Strahlung |
| [[03_6_u_wert_berechnung\|Kap. 3.6]] | U-Wert-Berechnung |
| [[04_Theorie_Feuchte\|Kap. 4]] | Theorie der feuchten Luft |
| [[05_1_2_grundlagen_natuerliche_lueftung\|Kap. 5.1–5.2]] | Grundlagen Luftdichtheit und natürliche Lüftung |
| [[05_3_4_lufterneuerung_radon\|Kap. 5.3–5.4]] | Lufterneuerung und Radon |
| [[05_5_luftfeuchtigkeit\|Kap. 5.5]] | Luftfeuchtigkeit |
| [[05_6_7_ueberpruefung_anforderungen\|Kap. 5.6–5.7]] | Überprüfung und Anforderungen |
| [[05_8_9_mechanische_lueftung\|Kap. 5.8–5.9]] | Mechanische Lüftung |

---

## Energieflüsse im Gebäude

| Kapitel | Inhalt |
|---|---|
| [[01_Grundlagen\|Kap. 1]] | Grundlagen |
| [[02_Waermeverluste\|Kap. 2]] | Wärmeverluste |
| [[03_1_interne_waermegewinne\|Kap. 3.1]] | Interne Wärmegewinne |
| [[03_2_solare_waermegewinne\|Kap. 3.2]] | Solare Wärmegewinne |
| [[03_3_waermespeicherung\|Kap. 3.3]] | Wärmespeicherung |
| [[04_Heizwaermebedarf\|Kap. 4]] | Heizwärmebedarf |
| [[05_Warmwasser\|Kap. 5]] | Wärmebedarf Warmwasser |
| [[06_1_berechnung_energiebedarf\|Kap. 6.1]] | Berechnung des Energiebedarfs |
| [[06_2_primaerenergie\|Kap. 6.2]] | Primärenergie |
| [[06_3_deckung_energiebedarf\|Kap. 6.3]] | Deckung des Energiebedarfs |
| [[06_4_vorschriften\|Kap. 6.4]] | Vorschriften |
| [[06_5_standards_labels\|Kap. 6.5]] | Standards und Labels |
| [[06_6_vergleich_bauweise\|Kap. 6.6]] | Vergleich der Bauweise |
| [[06_7_nutzereinfluss\|Kap. 6.7]] | Nutzereinfluss |
| [[07_1_bauweise_beschattung\|Kap. 7.1]] | Bauweise und Beschattung |
| [[07_2_deckung_kuehlenergiebedarf\|Kap. 7.2]] | Deckung des Kühlenergiebedarfs |
| [[07_3_freie_kuehlung\|Kap. 7.3]] | Freie Kühlung |
| [[07_4_5_mechanische_kuehlung_energiebedarf\|Kap. 7.4–7.5]] | Mechanische Kühlung und Energiebedarf |
| [[08_Anhang\|Kap. 8]] | Anhang |

---

*Alle Inhalte © Prof. Markus Hubbuch, ZHAW*
